package com.savora.downloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    @Volatile var ready = false

    @Synchronized
    fun update(ctx: Context) {
        val ytdl = YoutubeDL.getInstance()
        val m = Class.forName("com.yausername.youtubedl_android.YoutubeDL").methods
            .filter { it.name == "updateYoutubeDL" }.maxByOrNull { it.parameterCount }
            ?: throw IllegalStateException("update not supported")
        val args = m.parameterTypes.map { t ->
            when {
                Context::class.java.isAssignableFrom(t) -> ctx.applicationContext
                t.isEnum -> t.enumConstants!!.firstOrNull { (it as Enum<*>).name.contains("NIGHTLY", true) }
                    ?: t.enumConstants!!.first()
                else -> null
            }
        }
        try {
            m.invoke(ytdl, *args.toTypedArray())
        } catch (e: java.lang.reflect.InvocationTargetException) {
            throw e.targetException ?: e
        }
        ready = true
    }

    fun ensure(ctx: Context) {
        if (ready) return
        ready = runCatching { update(ctx) }.isSuccess
    }
}
