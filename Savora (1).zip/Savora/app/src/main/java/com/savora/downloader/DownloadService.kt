package com.savora.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_MODE = "mode"
        const val EXTRA_ID = "id"
        const val ACTION_CANCEL = "com.savora.downloader.CANCEL"
        private const val CH_SERVICE = "svc"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val FG_ID = 1
        private const val ACCENT = 0xFFFFC91F.toInt()
        private val nextId = AtomicInteger(100)
        private val cancelled = ConcurrentHashMap.newKeySet<Int>()
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = AtomicInteger(0)
    private val nm by lazy { getSystemService(NotificationManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()

        if (intent?.action == ACTION_CANCEL) {
            val id = intent.getIntExtra(EXTRA_ID, -1)
            cancelled.add(id)
            runCatching { YoutubeDL.getInstance().destroyProcessById("savora_$id") }
            nm.cancel(id)
            if (active.get() == 0) stopSelf()
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(this, FG_ID, summaryNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val url = intent?.getStringExtra(EXTRA_URL)
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: "v720"
        if (url == null) {
            finishIfIdle()
            return START_NOT_STICKY
        }

        val id = nextId.incrementAndGet()
        active.incrementAndGet()
        scope.launch {
            try {
                runDownload(id, url, mode)
            } finally {
                active.decrementAndGet()
                finishIfIdle()
            }
        }
        return START_NOT_STICKY
    }

    private fun finishIfIdle() {
        if (active.get() == 0) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun createChannels() {
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Background service", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Download finished", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun summaryNotification(): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("Savora is downloading")
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun progressNotification(id: Int, title: String, p: Int): Notification {
        val cancel = PendingIntent.getService(
            this, id,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle(title)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Cancel", cancel)
        if (p < 0) b.setContentText("Starting…").setProgress(0, 0, true)
        else b.setContentText("Downloading… $p%").setProgress(100, p, false)
        return b.build()
    }

    private fun doneNotification(id: Int, name: String, uri: Uri?, mime: String): Notification {
        val open = if (uri != null) PendingIntent.getActivity(
            this, id,
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ) else openAppIntent()
        return NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle("Download complete")
            .setContentText(name)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
    }

    private fun failNotification(e: Throwable): Notification {
        val msg = e.message ?: ""
        val text = if (msg.contains("No video formats", true))
            "Couldn't read this video. It may be private. Open Savora → Settings → Update download engine and try again."
        else msg.take(160).ifEmpty { "Unknown error" }
        return NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle("Download failed")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
    }

    private fun videoFormat(h: Int) =
        "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/b[height<=$h][ext=mp4]/bv*[height<=$h]+ba/b[height<=$h]/b"

    private fun runDownload(id: Int, url: String, mode: String) {
        var title = "Preparing…"
        var titleSet = false
        val dir = File(cacheDir, "dl_$id")
        try {
            nm.notify(id, progressNotification(id, if (Engine.ready) title else "Updating download engine…", -1))
            Engine.ensure(this)
            dir.deleteRecursively(); dir.mkdirs()

            val req = YoutubeDLRequest(url)
            req.addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
            req.addOption("--no-playlist")
            when (mode) {
                "m4a" -> req.addOption("-f", "bestaudio[ext=m4a]/bestaudio")
                "mp3" -> { req.addOption("-x"); req.addOption("--audio-format", "mp3") }
                "v360" -> { req.addOption("-f", videoFormat(360)); req.addOption("--merge-output-format", "mp4") }
                "v720" -> { req.addOption("-f", videoFormat(720)); req.addOption("--merge-output-format", "mp4") }
                else -> { req.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"); req.addOption("--merge-output-format", "mp4") }
            }

            nm.notify(id, progressNotification(id, title, -1))
            var last = -1
            YoutubeDL.getInstance().execute(req, "savora_$id") { p, _, line ->
                var changed = false
                if (!titleSet) {
                    Regex("Destination: (.+)$").find(line ?: "")?.let { m ->
                        title = File(m.groupValues[1].trim()).nameWithoutExtension
                        titleSet = true
                        changed = true
                    }
                }
                val v = p.toInt()
                if (v in 0..100 && v != last) { last = v; changed = true }
                if (changed && last >= 0) nm.notify(id, progressNotification(id, title, last))
            }

            val files = dir.listFiles()?.filter {
                it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
            }.orEmpty()
            if (files.isEmpty()) throw IllegalStateException("Nothing was downloaded")

            var firstUri: Uri? = null
            var firstMime = ""
            var firstName = ""
            files.forEach { f ->
                val (u, m) = saveToDownloads(f)
                if (firstUri == null) { firstUri = u; firstMime = m; firstName = f.nameWithoutExtension }
            }
            nm.notify(id, doneNotification(id, firstName, firstUri, firstMime))
        } catch (e: Throwable) {
            if (cancelled.contains(id)) nm.cancel(id) else nm.notify(id, failNotification(e))
        } finally {
            dir.deleteRecursively()
            cancelled.remove(id)
        }
    }

    private fun saveToDownloads(f: File): Pair<Uri?, String> {
        val mime = when (f.extension.lowercase()) {
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "opus", "ogg" -> "audio/ogg"
            else -> "application/octet-stream"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Savora")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        }
        return Pair(uri, mime)
    }
}
