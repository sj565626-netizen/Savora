package com.savora.downloader

import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.ContentValues
import android.app.DownloadManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.format.Formatter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.lifecycle.lifecycleScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : AppCompatActivity() {

    private data class Platform(val name: String, val glyph: String, val color: String, val url: String)
    private data class Item(val uri: Uri, val name: String, val size: Long, val mime: String, val dur: Long, val thumb: Bitmap?)

    private val yellow = Color.parseColor("#FFC91F")
    private val gray = Color.parseColor("#8A8A8A")

    private val tabIds = listOf(R.id.tab0, R.id.tab1, R.id.tab2, R.id.tab3)
    private val ulIds = listOf(R.id.ul0, R.id.ul1, R.id.ul2, R.id.ul3)
    private val bodyIds = listOf(R.id.tabSearch, R.id.tabYoutube, R.id.tabMusic, R.id.tabMore)
    private val pageIds = listOf(R.id.pageDownload, R.id.pagePlay, R.id.pageSettings)
    private val navIds = listOf(R.id.nav0, R.id.nav1, R.id.nav2)
    private val navIconIds = listOf(R.id.navIcon0, R.id.navIcon1, R.id.navIcon2)
    private val navLabelIds = listOf(R.id.navLabel0, R.id.navLabel1, R.id.navLabel2)

    private lateinit var urlInput: EditText

    private val platforms = listOf(
        Platform("YouTube", "▶", "#FF2D2D", "https://www.youtube.com"),
        Platform("TikTok", "♪", "#25F4EE", "https://www.tiktok.com"),
        Platform("Instagram", "◎", "#D62976", "https://www.instagram.com"),
        Platform("Facebook", "f", "#2B7BFF", "https://www.facebook.com"),
        Platform("Pinterest", "P", "#E60023", "https://www.pinterest.com"),
        Platform("Threads", "@", "#DDDDDD", "https://www.threads.net"),
        Platform("SnapChat", "S", "#FFE600", "https://www.snapchat.com"),
        Platform("DailyMotion", "d", "#E0508A", "https://www.dailymotion.com"),
        Platform("SoundCloud", "☁", "#FF5500", "https://soundcloud.com"),
        Platform("BlueSky", "b", "#1185FE", "https://bsky.app"),
        Platform("OkRu", "OK", "#F58220", "https://ok.ru")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        urlInput = findViewById(R.id.urlInput)

        findViewById<View>(R.id.btnGo).setOnClickListener { start() }
        urlInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { start(); true } else false
        }
        tabIds.forEachIndexed { i, id -> findViewById<View>(id).setOnClickListener { selectTab(i) } }
        navIds.forEachIndexed { i, id -> findViewById<View>(id).setOnClickListener { selectPage(i) } }

        buildInfoTab(R.id.tabYoutube, "▶", "#FF2D2D", "YouTube",
            "Open YouTube, tap Share on any video and choose Savora. The download starts automatically.",
            "Open YouTube", "https://www.youtube.com")
        buildInfoTab(R.id.tabMusic, "♪", "#FF5A5F", "Music",
            "Open YouTube Music or any music site, tap Share on a song and choose Savora. Select Audio (MP3) for songs.",
            "Open YouTube Music", "https://music.youtube.com")
        buildMore()
        buildSettings()
        selectPage(0)
        selectTab(0)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && urlInput.text.isNullOrEmpty()) {
            runCatching {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
                Regex("https?://\\S+").find(t)?.let { urlInput.setText(it.value) }
            }
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            urlInput.setText(Regex("https?://\\S+").find(t)?.value ?: t)
            selectPage(0); selectTab(0)
            start()
        }
    }

    // ---------- navigation ----------
    private fun selectPage(i: Int) {
        pageIds.forEachIndexed { idx, id -> findViewById<View>(id).visibility = if (idx == i) View.VISIBLE else View.GONE }
        navIconIds.forEachIndexed { idx, id ->
            findViewById<ImageView>(id).setColorFilter(if (idx == i) Color.WHITE else gray)
            findViewById<TextView>(navLabelIds[idx]).setTextColor(if (idx == i) Color.WHITE else gray)
        }
        if (i == 1) loadDownloads()
    }

    private fun selectTab(i: Int) {
        tabIds.forEachIndexed { idx, id ->
            findViewById<TextView>(id).setTextColor(if (idx == i) Color.WHITE else gray)
            findViewById<View>(ulIds[idx]).visibility = if (idx == i) View.VISIBLE else View.INVISIBLE
            findViewById<View>(bodyIds[idx]).visibility = if (idx == i) View.VISIBLE else View.GONE
        }
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int = Color.TRANSPARENT, strokeW: Int = 0) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius.toFloat()
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    private fun yellowButton(label: String) = TextView(this).apply {
        text = label
        setTextColor(Color.BLACK)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 14f
        gravity = Gravity.CENTER
        background = rounded(yellow, dp(22))
        setPadding(dp(28), dp(12), dp(28), dp(12))
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun glyphBox(glyph: String, color: String, size: Int) = TextView(this).apply {
        text = glyph
        gravity = Gravity.CENTER
        textSize = (size / 2.6f)
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.parseColor(color))
        background = rounded(Color.TRANSPARENT, dp(size / 3), Color.parseColor(color), dp(3))
    }

    // ---------- tabs ----------
    private fun buildInfoTab(id: Int, glyph: String, color: String, title: String, desc: String, btn: String, url: String) {
        val c = findViewById<LinearLayout>(id)
        c.addView(glyphBox(glyph, color, 96).apply { layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)) })
        c.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(24), 0, dp(8))
        })
        c.addView(TextView(this).apply {
            text = desc; setTextColor(Color.parseColor("#B0B0B0")); textSize = 15f
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(24))
        })
        c.addView(yellowButton(btn).apply { setOnClickListener { openUrl(url) } })
    }

    private fun buildMore() {
        val list = findViewById<LinearLayout>(R.id.moreList)
        platforms.forEach { p ->
            val card = FrameLayout(this).apply {
                background = rounded(Color.parseColor("#1C1C1C"), dp(24), Color.parseColor("#2A2A2A"), dp(1))
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(20), dp(8), dp(20), dp(8)) }
                setPadding(dp(20), dp(22), dp(20), dp(22))
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_download); setColorFilter(gray)
                layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
            })
            row.addView(TextView(this).apply {
                text = p.name; setTextColor(Color.WHITE); textSize = 17f
                typeface = Typeface.DEFAULT_BOLD; setPadding(dp(12), 0, 0, 0)
            })
            col.addView(row)
            col.addView(yellowButton("How to start").apply {
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) }
                setOnClickListener { showHowTo(p) }
            })
            card.addView(col)
            card.addView(glyphBox(p.glyph, p.color, 60).apply {
                alpha = 0.6f
                layoutParams = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.END or Gravity.BOTTOM)
            })
            list.addView(card)
        }
    }

    private fun showHowTo(p: Platform) {
        AlertDialog.Builder(this)
            .setTitle(p.name)
            .setMessage("1. Open ${p.name}\n2. Tap Share on a video or post\n3. Choose Savora\n\nDownload starts automatically. You can also copy the link and paste it in the Search tab.")
            .setPositiveButton("Open ${p.name}") { _, _ -> openUrl(p.url) }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- settings ----------
    private fun buildSettings() {
        val l = findViewById<LinearLayout>(R.id.settingsList)
        l.addView(sectionHeader("Download tools"))
        l.addView(settingRow(R.drawable.ic_download, "Update download engine") { manualUpdate() })
        l.addView(settingRow(R.drawable.ic_folder, "Open Downloads folder") {
            runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
        })
        l.addView(sectionHeader("Info"))
        l.addView(settingRow(R.drawable.ic_share, "Share Savora") {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Try Savora - save videos and audio from your favourite platforms.")
            startActivity(Intent.createChooser(i, "Share Savora"))
        })
        l.addView(settingRow(R.drawable.ic_info, "About") {
            AlertDialog.Builder(this).setTitle("Savora 1.0")
                .setMessage("Video and audio downloader powered by yt-dlp.\n\nPlease download only content you own or have permission to save, and respect creators' copyright.")
                .setPositiveButton("OK", null).show()
        })
    }

    private fun sectionHeader(t: String) = TextView(this).apply {
        text = t; setTextColor(gray); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(20), dp(24), dp(20), dp(8))
    }

    private fun settingRow(icon: Int, title: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon); setColorFilter(gray)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        })
        row.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(20), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        })
        row.addView(TextView(this).apply { text = "›"; setTextColor(gray); textSize = 22f })
        return row
    }

    // ---------- engine / download ----------
    private fun manualUpdate() {
        toast("Updating engine… please wait")
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Engine.update(applicationContext) } }
            toast(if (r.isSuccess) "Engine updated" else "Update failed: ${r.exceptionOrNull()?.message?.take(80)}")
        }
    }

    private fun start() {
        val raw = urlInput.text.toString().trim()
        val url = Regex("https?://\\S+").find(raw)?.value ?: raw
        if (url.isEmpty()) { toast("Paste a link first"); return }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlInput.windowToken, 0)
        startActivity(
            Intent(this, ShareActivity::class.java)
                .setAction(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, url)
        )
    }

    // ---------- downloaded list ----------
    private fun loadDownloads() {
        val list = findViewById<LinearLayout>(R.id.downloadList)
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { runCatching { queryDownloads() }.getOrDefault(emptyList()) }
            list.removeAllViews()
            if (items.isEmpty()) {
                list.addView(TextView(this@MainActivity).apply {
                    text = "No downloads yet"; setTextColor(gray); textSize = 15f
                    setPadding(dp(20), dp(20), dp(20), dp(20))
                })
            }
            items.forEach { list.addView(itemRow(it)) }
        }
    }

    private fun queryDownloads(): List<Item> {
        val out = mutableListOf<Item>()
        val proj = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE, MediaStore.Downloads.MIME_TYPE)
        contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj,
            "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?", arrayOf("Download/Savora%"),
            "${MediaStore.Downloads.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext() && out.size < 100) {
                val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
                val mime = c.getString(3) ?: ""
                var dur = 0L
                runCatching {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(this, uri)
                    dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    r.release()
                }
                val thumb = if (mime.startsWith("video"))
                    runCatching { contentResolver.loadThumbnail(uri, Size(192, 192), null) }.getOrNull() else null
                out.add(Item(uri, c.getString(1) ?: "file", c.getLong(2), mime, dur, thumb))
            }
        }
        return out
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        return if (h > 0) String.format("%d:%02d:%02d", h, (s % 3600) / 60, s % 60)
        else String.format("%02d:%02d", s / 60, s % 60)
    }

    private fun itemRow(item: Item): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(10), dp(8), dp(10))
            setOnClickListener {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(item.uri, item.mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }.onFailure { toast("No app found to open this file") }
            }
        }
        val isAudio = item.mime.startsWith("audio")
        val thumb = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
            background = rounded(Color.parseColor("#262626"), dp(12))
            clipToOutline = true
            if (item.thumb != null) {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(item.thumb)
            } else {
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(18), dp(18), dp(18), dp(18))
                setImageResource(if (isAudio) R.drawable.ic_music else R.drawable.ic_play)
                setColorFilter(yellow)
            }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14); marginEnd = dp(8) }
        }
        col.addView(TextView(this).apply {
            text = item.name; setTextColor(Color.WHITE); textSize = 15f
            typeface = Typeface.DEFAULT_BOLD; maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val size = Formatter.formatShortFileSize(this, item.size)
        col.addView(TextView(this).apply {
            text = if (item.dur > 0) "${fmtDur(item.dur)}  |  $size" else size
            setTextColor(gray); textSize = 12f; setPadding(0, dp(6), 0, 0)
        })
        val more = ImageView(this).apply {
            setImageResource(R.drawable.ic_more); setColorFilter(gray)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        more.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add("Share")
            pm.menu.add("Delete")
            pm.setOnMenuItemClickListener { mi ->
                when (mi.title.toString()) {
                    "Share" -> startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType(item.mime)
                            .putExtra(Intent.EXTRA_STREAM, item.uri)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
                    "Delete" -> {
                        runCatching { contentResolver.delete(item.uri, null, null) }
                        loadDownloads()
                    }
                }
                true
            }
            pm.show()
        }
        row.addView(thumb); row.addView(col); row.addView(more)
        return row
    }
}
