package com.savora.downloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

class ShareActivity : AppCompatActivity() {

    private data class Opt(val mode: String, val label: String, val music: Boolean)

    private val yellow = Color.parseColor("#2D7BFF")
    private val gray = Color.parseColor("#8A8A8A")
    private val musicOpts = listOf(Opt("m4a", "Fast (M4A)", true), Opt("mp3", "Classic MP3", true))
    private val videoOpts = listOf(Opt("v360", "Fast (360p)", false), Opt("v720", "High quality (720p)", false), Opt("best", "Best quality", false))

    private var selected = "v720"
    private var toVault = false
    private var url = ""
    private val checks = mutableMapOf<String, TextView>()
    private val sizeViews = mutableMapOf<String, TextView>()
    private lateinit var sheet: BottomSheetDialog

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startDownload() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val u = Regex("https?://\\S+").find(text)?.value
        if (u == null) {
            Toast.makeText(this, "No link found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        url = u
        showSheet()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(fill: Int, stroke: Int, w: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        if (w > 0) setStroke(w, stroke)
    }

    private fun select(mode: String) {
        selected = mode
        checks.forEach { (m, tv) ->
            if (m == mode) {
                tv.text = "✓"; tv.setTextColor(Color.WHITE); tv.background = circle(yellow, yellow, 0)
            } else {
                tv.text = ""; tv.background = circle(Color.TRANSPARENT, gray, dp(2))
            }
        }
    }

    private fun section(t: String) = TextView(this).apply {
        text = t; setTextColor(gray); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(18), 0, dp(4))
    }

    private fun row(o: Opt): View {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { select(o.mode) }
        }
        r.addView(ImageView(this).apply {
            setImageResource(if (o.music) R.drawable.ic_music else R.drawable.ic_play)
            setColorFilter(Color.parseColor("#CFCFCF"))
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(26))
        })
        r.addView(TextView(this).apply {
            text = o.label; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(20), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val sizeTv = TextView(this).apply {
            text = "…"; setTextColor(gray); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, dp(14), 0)
        }
        sizeViews[o.mode] = sizeTv
        r.addView(sizeTv)
        val check = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
        }
        checks[o.mode] = check
        r.addView(check)
        return r
    }

    private fun showSheet() {
        sheet = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val r = dp(24).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1C1C1C"))
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(22), dp(12), dp(22), dp(24))
        }
        root.addView(View(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#555555")); cornerRadius = dp(2).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(18) }
        })
        root.addView(TextView(this).apply {
            text = "Download video as"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = url; setTextColor(gray); textSize = 12f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
        })
        root.addView(section("Music"))
        musicOpts.forEach { root.addView(row(it)) }
        root.addView(section("Video"))
        videoOpts.forEach { root.addView(row(it)) }
        root.addView(android.widget.CheckBox(this).apply {
            text = "Save to Vault (hidden, PIN protected)"
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(8), dp(6), 0, dp(6))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(14) }
            setOnCheckedChangeListener { _, c -> toVault = c }
        })
        root.addView(TextView(this).apply {
            text = "Download"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(yellow); cornerRadius = dp(28).toFloat() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(20) }
            setOnClickListener { onDownloadClicked() }
        })
        select(selected)

        sheet.setContentView(root)
        sheet.setOnDismissListener { finish() }
        sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        sheet.behavior.skipCollapsed = true
        sheet.show()
        sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        loadSizes()
    }

    private fun loadSizes() {
        lifecycleScope.launch {
            val sizes = withContext(Dispatchers.IO) { runCatching { fetchSizes() }.getOrNull() }
            sizeViews.forEach { (mode, tv) ->
                val b = sizes?.get(mode)
                tv.text = if (b != null && b > 0) "~" + android.text.format.Formatter.formatShortFileSize(this@ShareActivity, b) else ""
            }
        }
    }

    private data class Fmt(val h: Int, val size: Long, val v: Boolean, val a: Boolean, val ext: String)

    private fun fetchSizes(): Map<String, Long> {
        Engine.ensure(this)
        val req = YoutubeDLRequest(url)
        req.addOption("-J")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--force-ipv4")
        req.addOption("--socket-timeout", "30")
        val out = YoutubeDL.getInstance().execute(req).out
        val j = JSONObject(out.substring(out.indexOf('{')))
        val dur = j.optDouble("duration", 0.0)
        val arr = j.optJSONArray("formats") ?: return emptyMap()

        val fs = mutableListOf<Fmt>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var size = o.optLong("filesize", 0L)
            if (size <= 0) size = o.optDouble("filesize_approx", 0.0).toLong()
            if (size <= 0) {
                val tbr = o.optDouble("tbr", 0.0)
                if (tbr > 0 && dur > 0) size = (tbr * 1000 / 8 * dur).toLong()
            }
            val vc = o.optString("vcodec", "none")
            val ac = o.optString("acodec", "none")
            fs.add(Fmt(o.optInt("height", 0), size,
                vc != "none" && vc != "null", ac != "none" && ac != "null", o.optString("ext", "")))
        }

        val audioOnly = fs.filter { !it.v && it.a && it.size > 0 }
        val audioSize = audioOnly.filter { it.ext == "m4a" }.maxOfOrNull { it.size }
            ?: audioOnly.maxOfOrNull { it.size } ?: 0L

        fun videoTotal(maxH: Int): Long {
            val best = fs.filter { it.v && it.h in 1..maxH && it.size > 0 }
                .sortedWith(compareBy<Fmt>({ it.h }, { it.ext == "mp4" })).lastOrNull() ?: return 0L
            return best.size + (if (best.a) 0L else audioSize)
        }

        val res = mutableMapOf<String, Long>()
        res["m4a"] = audioSize
        res["mp3"] = if (dur > 0) (dur * 128000 / 8).toLong() else audioSize
        res["v360"] = videoTotal(360)
        res["v720"] = videoTotal(720)
        res["best"] = videoTotal(Int.MAX_VALUE)
        return res
    }

    private fun onDownloadClicked() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startDownload()
        }
    }

    private fun startDownload() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, url)
                .putExtra(DownloadService.EXTRA_MODE, selected)
                .putExtra(DownloadService.EXTRA_VAULT, toVault)
        )
        Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
        sheet.dismiss()
        finish()
    }
}
