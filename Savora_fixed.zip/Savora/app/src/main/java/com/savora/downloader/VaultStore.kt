package com.savora.downloader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Base64
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Private vault: files live in the app's own storage (not visible in Gallery / Files / Downloads)
 * and are opened only after the PIN is entered.
 */
object VaultStore {
    private const val PREFS = "vault"
    private const val K_HASH = "pin_hash"
    private const val K_SALT = "pin_salt"
    private const val K_FAILS = "fails"
    private const val K_LOCK_UNTIL = "lock_until"
    private const val ITER = 60_000

    fun dir(ctx: Context): File = File(ctx.filesDir, "vault").apply { mkdirs() }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- PIN ----------
    fun hasPin(ctx: Context) = prefs(ctx).getString(K_HASH, null) != null

    private fun hash(pin: String, salt: ByteArray): String {
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, ITER, 256)).encoded
        return Base64.encodeToString(key, Base64.NO_WRAP)
    }

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(ctx).edit()
            .putString(K_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(K_HASH, hash(pin, salt))
            .putInt(K_FAILS, 0).putLong(K_LOCK_UNTIL, 0)
            .apply()
    }

    /** Seconds the user must still wait after too many wrong PINs (0 = not locked out). */
    fun lockedForSeconds(ctx: Context): Int {
        val left = prefs(ctx).getLong(K_LOCK_UNTIL, 0) - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    fun checkPin(ctx: Context, pin: String): Boolean {
        if (lockedForSeconds(ctx) > 0) return false
        val p = prefs(ctx)
        val salt = Base64.decode(p.getString(K_SALT, "") ?: "", Base64.NO_WRAP)
        val expected = p.getString(K_HASH, null) ?: return false
        val ok = MessageDigest.isEqual(hash(pin, salt).toByteArray(), expected.toByteArray())
        if (ok) {
            p.edit().putInt(K_FAILS, 0).putLong(K_LOCK_UNTIL, 0).apply()
        } else {
            val fails = p.getInt(K_FAILS, 0) + 1
            val e = p.edit().putInt(K_FAILS, fails)
            // 5 wrong tries -> 30 s, then grows each further miss (max 10 min)
            if (fails >= 5) {
                val wait = minOf(30_000L * (fails - 4), 600_000L)
                e.putLong(K_LOCK_UNTIL, System.currentTimeMillis() + wait)
            }
            e.apply()
        }
        return ok
    }

    /** Forgot PIN: erases every vault file and the PIN. */
    fun eraseAll(ctx: Context) {
        dir(ctx).deleteRecursively()
        prefs(ctx).edit().clear().apply()
    }

    // ---------- files ----------
    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }.orEmpty()

    private fun uniqueTarget(ctx: Context, name: String): File {
        var f = File(dir(ctx), name)
        var n = 1
        val base = f.nameWithoutExtension
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        while (f.exists()) f = File(dir(ctx), "$base ($n)$ext").also { n++ }
        return f
    }

    /** Move a finished download (cache file) straight into the vault. */
    fun addFile(ctx: Context, src: File): File {
        val target = uniqueTarget(ctx, src.name)
        if (!src.renameTo(target)) {
            src.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            src.delete()
        }
        return target
    }

    /** Move an item from Downloads/Savora (MediaStore) into the vault. Returns false on failure. */
    fun importFromMediaStore(ctx: Context, uri: Uri, name: String): Boolean = runCatching {
        val target = uniqueTarget(ctx, name)
        ctx.contentResolver.openInputStream(uri)!!.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
        if (ctx.contentResolver.delete(uri, null, null) <= 0) {
            // copy succeeded but the original could not be removed -> undo so nothing is left half-hidden
            target.delete()
            return false
        }
        true
    }.getOrDefault(false)

    /** Move a vault file back to Downloads/Savora so it shows in Gallery/Files again. */
    fun restore(ctx: Context, f: File): Boolean = runCatching {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime(f))
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Savora")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
    }.getOrDefault(false)

    fun mime(f: File): String = when (f.extension.lowercase()) {
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "opus", "ogg" -> "audio/ogg"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        else -> "application/octet-stream"
    }
}
