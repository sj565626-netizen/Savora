package com.savora.downloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_MODE = "mode"
        const val EXTRA_ID = "id"
        const val EXTRA_VAULT = "vault"
        const val ACTION_CANCEL = "com.savora.downloader.CANCEL"
        const val ACTION_PAUSE = "com.savora.downloader.PAUSE"
        const val ACTION_RESUME = "com.savora.downloader.RESUME"
        private const val CH_SERVICE = "svc"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val FG_ID = 1
        private const val ACCENT = 0xFF2D7BFF.toInt()
        private val nextId = AtomicInteger(100)
        private val cancelled = ConcurrentHashMap.newKeySet<Int>()
        private val paused = ConcurrentHashMap.newKeySet<Int>()
    }

    private val urls = ConcurrentHashMap<Int, String>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active = AtomicInteger(0)
    private val nm by lazy { getSystemService(NotificationManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()

        if (intent?.action == ACTION_CANCEL) {
            val id = intent.getIntExtra(EXTRA_ID, -1)
            cancelled.add(id)
            runCatching { YoutubeDL.getInstance().destroyProcessById("savora_$id") }
            nm.cancel(id)
            DownloadTracker.remove(id, false)
            if (active.get() == 0) stopSelf()
            return START_NOT_STICKY
        }

        val act = intent?.action
        if (intent != null && (act == ACTION_PAUSE || act == ACTION_RESUME)) {
            val id = intent.getIntExtra(EXTRA_ID, -1)
            if (urls.containsKey(id)) {
                if (act == ACTION_PAUSE) {
                    paused.add(id)
                    runCatching { YoutubeDL.getInstance().destroyProcessById("savora_$id") }
                    DownloadTracker.setPaused(id, true)
                    val t = DownloadTracker.get(id)
                    nm.notify(id, progressNotification(id, t?.name?.ifEmpty { "Download" } ?: "Download", t?.pct ?: -1, true))
                } else {
                    paused.remove(id)
                    DownloadTracker.setPaused(id, false)
                }
            }
            if (active.get() == 0) stopSelf()
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(this, FG_ID, summaryNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val url = intent?.getStringExtra(EXTRA_URL)
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: "v720"
        val vault = intent?.getBooleanExtra(EXTRA_VAULT, false) ?: false
        if (url == null) {
            finishIfIdle()
            return START_NOT_STICKY
        }

        val id = nextId.incrementAndGet()
        urls[id] = url
        DownloadTracker.update(id, "Preparing…", -1, url)
        active.incrementAndGet()
        scope.launch {
            try {
                runDownload(id, url, mode, vault)
            } finally {
                active.decrementAndGet()
                finishIfIdle()
            }
        }
        return START_NOT_STICKY
    }

    private fun finishIfIdle() {
        if (active.get() == 0) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            Engine.refreshInBackground(applicationContext)
        }
    }

    private fun createChannels() {
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Background service", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Download finished", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun summaryNotification(): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("Savora is downloading")
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun progressNotification(id: Int, title: String, p: Int, isPaused: Boolean = false): Notification {
        if (!isPaused) DownloadTracker.update(id, title, p, urls[id] ?: "")
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val cancel = PendingIntent.getService(
            this, id,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_ID, id), flags
        )
        val toggle = PendingIntent.getService(
            this, id + 500_000,
            Intent(this, DownloadService::class.java)
                .setAction(if (isPaused) ACTION_RESUME else ACTION_PAUSE).putExtra(EXTRA_ID, id), flags
        )
        val b = NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle(title)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .addAction(0, if (isPaused) "Resume" else "Pause", toggle)
            .addAction(0, "Cancel", cancel)
        if (isPaused) b.setContentText(if (p >= 0) "Paused at $p%" else "Paused").setProgress(100, p.coerceAtLeast(0), false)
        else if (p < 0) b.setContentText(if (title.endsWith("…")) title else "Starting…").setProgress(0, 0, true)
        else b.setContentText("Downloading… $p%").setProgress(100, p, false)
        return b.build()
    }

    private fun vaultDoneNotification(name: String): Notification =
        NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle("Saved to Vault")
            .setContentText(name)
            .setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(
                this, 7, Intent(this, VaultActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            .build()

    private fun doneNotification(id: Int, name: String, uri: Uri?, mime: String): Notification {
        val open = if (uri != null) PendingIntent.getActivity(
            this, id,
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ) else openAppIntent()
        return NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle("Download complete")
            .setContentText(name)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
    }

    /** yt-dlp dumps every WARNING into the exception text; show only the real ERROR line. */
    private fun friendlyError(e: Throwable): String {
        val raw = e.message ?: ""
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val errLine = lines.lastOrNull { it.contains("ERROR", true) && !it.startsWith("WARNING") }
            ?: lines.lastOrNull() ?: ""
        val m = raw
        return when {
            m.contains("No space left", true) || m.contains("ENOSPC", true) ->
                "Phone storage is full. Free some space (a movie needs about 2-3x its size while it is being prepared) and try again."
            m.contains("timed out", true) || m.contains("handshake", true) ->
                "Network timed out. Check your internet, try Wi-Fi or switch data on/off, then try again."
            m.contains("Precondition check failed", true) || m.contains("HTTP Error 400", true) ||
                m.contains("HTTP Error 403", true) || m.contains("JavaScript runtime", true) ||
                m.contains("Sign in to confirm", true) ->
                "The site rejected the request. Open Savora → Settings → Update download engine, then try again.\n[${errLine.removePrefix("ERROR:").trim().take(140)}]"
            m.contains("No video formats", true) || m.contains("Unsupported URL", true) ->
                "Couldn't read this link. The video may be private, or the site isn't supported. Update the download engine and try again.\n[${errLine.removePrefix("ERROR:").trim().take(140)}]"
            m.contains("login required", true) || m.contains("cookies", true) || m.contains("private", true) ||
                m.contains("Cannot parse data", true) ->
                "This video is private or needs a login, so it can't be downloaded."
            else -> errLine.removePrefix("ERROR:").trim().take(200).ifEmpty { "Unknown error" }
        }
    }

    private fun failNotification(e: Throwable): Notification {
        val text = friendlyError(e)
        return NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setColor(ACCENT)
            .setContentTitle("Download failed")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
    }

    private fun videoFormat(h: Int) =
        "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/b[height<=$h][ext=mp4]/bv*[height<=$h]+ba/b[height<=$h]/b"

    private fun runDownload(id: Int, url: String, mode: String, vault: Boolean) {
        var title = "Preparing…"
        var titleSet = false
        val dir = File(cacheDir, "dl_$id")
        try {
            nm.notify(id, progressNotification(id, title, -1))
            Engine.ensure(this)
            dir.deleteRecursively(); dir.mkdirs()

            var mergeContainer = "mp4"   // switched to mkv if mp4 merging fails after the download is complete

            fun buildReq(variant: Int): YoutubeDLRequest {
                val req = YoutubeDLRequest(url)
                Engine.tune(req, url, variant)
                req.addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                req.addOption("--no-playlist")
                req.addOption("--force-ipv4")
                req.addOption("--socket-timeout", "20")
                req.addOption("--retries", "5")
                req.addOption("--fragment-retries", "10")
                req.addOption("--extractor-retries", "1")
                req.addOption("--concurrent-fragments", "4")   // HLS/DASH fragments download in parallel
                req.addOption("--no-mtime")
                if (Engine.isYoutube(url)) req.addOption("--http-chunk-size", "10M") // avoids 403 in the middle of a download
                val lastResort = variant == Engine.variants(url) - 1
                when (mode) {
                    "m4a" -> req.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                    "mp3" -> { req.addOption("-f", "bestaudio/best"); req.addOption("-x"); req.addOption("--audio-format", "mp3") }
                    "v360", "v720" -> {
                        val h = if (mode == "v360") 360 else 720
                        // last resort: one progressive file (video+audio together), no merging, fewest requests
                        req.addOption("-f", if (lastResort) "b[height<=$h][ext=mp4]/b[ext=mp4]/b/bv*+ba" else videoFormat(h))
                        req.addOption("--merge-output-format", mergeContainer)
                    }
                    else -> { req.addOption("-f", if (lastResort) "b[ext=mp4]/b/bv*+ba" else "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"); req.addOption("--merge-output-format", mergeContainer) }
                }
                return req
            }

            nm.notify(id, progressNotification(id, title, -1))
            var last = -1
            var netAttempt = 0
            var variant = 0
            var engineRefreshed = false
            var resumeTries = 0
            var failMark = -1
            var downloadDone = false   // every stream is on disk, only merging / converting is left
            var mergeTries = 0
            val maxVariant = Engine.variants(url)
            while (true) {
                // Paused by the user: wait here, then continue from the .part files.
                if (paused.contains(id)) {
                    while (paused.contains(id) && !cancelled.contains(id)) Thread.sleep(500)
                    if (cancelled.contains(id)) throw IllegalStateException("cancelled")
                    nm.notify(id, progressNotification(id, "Resuming…", last))
                }
                try {
                    var stage = 0      // which stream is downloading now (1 = video, 2 = audio)
                    var streams = 1    // how many streams this download has
                    YoutubeDL.getInstance().execute(buildReq(variant), "savora_$id") { p, _, line ->
                        if (!paused.contains(id)) {
                            val ln = line ?: ""
                            var changed = false
                            Regex("Downloading \\d+ format\\(s\\): (\\S+)").find(ln)?.let { streams = it.groupValues[1].split("+").size }
                            Regex("Destination: (.+)$").find(ln)?.let { m ->
                                stage++
                                if (!titleSet) {
                                    title = File(m.groupValues[1].trim()).nameWithoutExtension.replace(Regex("\\.f[\\w-]+$"), "")
                                    titleSet = true
                                }
                                changed = true
                            }
                            if (!downloadDone && (ln.contains("[Merger]") || ln.contains("[ExtractAudio]") ||
                                    ln.contains("[VideoRemuxer]") || ln.contains("[Fixup"))) {
                                downloadDone = true
                                nm.notify(id, progressNotification(id, "Finishing…", -1))
                            }
                            val v = p.toInt()
                            if (!downloadDone && v in 0..100) {
                                // video + audio are two downloads: show ONE bar that only moves forward
                                val overall = if (streams >= 2) { if (stage <= 1) v * 85 / 100 else 85 + v * 14 / 100 } else v
                                if (overall > last) { last = overall; changed = true }
                            }
                            if (changed && last >= 0 && !downloadDone) nm.notify(id, progressNotification(id, title, last))
                        }
                    }
                    if (paused.contains(id)) continue   // the process was stopped by Pause, it did not really finish
                    break
                } catch (e: Throwable) {
                    if (cancelled.contains(id)) throw e
                    if (paused.contains(id)) continue   // Pause pressed: the loop waits at the top, then resumes
                    val m = e.message ?: ""

                    // 0) Phone storage is full: nothing can fix this by retrying.
                    if (m.contains("No space left", true) || m.contains("ENOSPC", true)) throw e

                    // 1) Slow / unstable connection: NOT a reason to change method. Same method, wait, resume.
                    val slowNet = m.contains("timed out", true) || m.contains("handshake", true) ||
                        m.contains("Connection reset", true) || m.contains("Connection aborted", true) ||
                        m.contains("Network is unreachable", true) || m.contains("Temporary failure", true) ||
                        m.contains("Name or service not known", true) || m.contains("IncompleteRead", true) ||
                        m.contains("EOF occurred", true) || m.contains("Read error", true)
                    // 2) Video itself is gone/private: no method can fix this, stop at once.
                    val permanent = m.contains("Private video", true) || m.contains("Video unavailable", true) ||
                        m.contains("has been removed", true) || m.contains("copyright", true) ||
                        m.contains("This video is private", true)

                    if (slowNet) {
                        netAttempt++
                        if (netAttempt > 5) throw e
                        nm.notify(id, progressNotification(id, "Slow connection, waiting ($netAttempt/5)…", last))
                        Thread.sleep(3000L * netAttempt)
                        continue   // same method; yt-dlp resumes from the .part file
                    }
                    if (permanent) throw e

                    // 3) Everything was already downloaded and only merging / converting failed.
                    //    NEVER throw the finished download away and start again: just redo the merge (mkv is more tolerant).
                    if (downloadDone) {
                        if (mergeTries < 2) {
                            mergeTries++
                            mergeContainer = "mkv"
                            nm.notify(id, progressNotification(id, "Finishing…", -1))
                            Thread.sleep(1000)
                            continue
                        }
                        throw e
                    }

                    // 4) Any other error / request rejected (400, 403, 429, "unable to extract", …):
                    //    a method that was already downloading is resumed first, then we switch.
                    val progressed = last >= 0
                    if (last > failMark) resumeTries = 0
                    failMark = last
                    if (progressed && resumeTries < 3) {
                        resumeTries++
                        nm.notify(id, progressNotification(id, "Resuming ($resumeTries/3)…", last))
                        Thread.sleep(2000)
                        continue
                    }
                    if (variant + 1 < maxVariant) {
                        variant++
                        dir.listFiles()?.forEach { it.delete() }
                        last = -1; failMark = -1; resumeTries = 0; netAttempt = 0
                        nm.notify(id, progressNotification(id, "Trying another method (${variant + 1}/$maxVariant)…", -1))
                        continue
                    }
                    // Every method failed: update the engine once (if no one else is doing it) and run the methods again.
                    if (!engineRefreshed && !Engine.updating) {
                        engineRefreshed = true
                        nm.notify(id, progressNotification(id, "Updating download engine…", -1))
                        if (runCatching { Engine.update(this) }.isSuccess) {
                            variant = 0
                            dir.listFiles()?.forEach { it.delete() }
                            last = -1; failMark = -1; resumeTries = 0; netAttempt = 0
                            continue
                        }
                    }
                    throw e
                }
            }

            val files = dir.listFiles()?.filter {
                it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") &&
                    it.extension.lowercase() !in setOf("json", "vtt", "srt", "description", "temp")
            }.orEmpty()
            if (files.isEmpty()) throw IllegalStateException("Nothing was downloaded")

            nm.notify(id, progressNotification(id, "Saving to phone…", -1))
            if (vault) {
                var n = ""
                files.forEach { f -> VaultStore.addFile(this, f); if (n.isEmpty()) n = f.nameWithoutExtension }
                nm.notify(id, vaultDoneNotification(n))
                DownloadTracker.remove(id, true)
            } else {
                var firstUri: Uri? = null
                var firstMime = ""
                var firstName = ""
                files.forEach { f ->
                    val (u, m) = saveToDownloads(f)
                    if (firstUri == null) { firstUri = u; firstMime = m; firstName = f.nameWithoutExtension }
                }
                nm.notify(id, doneNotification(id, firstName, firstUri, firstMime))
                DownloadTracker.remove(id, true)
            }
        } catch (e: Throwable) {
            if (cancelled.contains(id)) { nm.cancel(id); DownloadTracker.remove(id, false) }
            else { nm.notify(id, failNotification(e)); DownloadTracker.fail(id, friendlyError(e)) }
        } finally {
            dir.deleteRecursively()
            cancelled.remove(id)
            paused.remove(id)
            urls.remove(id)
        }
    }

    /** Copies the finished file into Downloads/Savora. It only appears in Gallery/Files once fully written. */
    private fun saveToDownloads(f: File): Pair<Uri?, String> {
        val mime = VaultStore.mime(f)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Savora")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Couldn't create the file in Downloads")
        try {
            contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out, 256 * 1024) } }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (e: Throwable) {
            runCatching { contentResolver.delete(uri, null, null) }
            throw e
        }
        f.delete()   // free the cache copy right away (movies are big)
        return Pair(uri, mime)
    }
}
