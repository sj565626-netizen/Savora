package com.savora.downloader

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ThumbnailUtils
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.text.format.Formatter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class VaultActivity : AppCompatActivity() {

    private val blue = Color.parseColor("#2D7BFF")
    private val gray = Color.parseColor("#8A8A8A")
    private val bg = Color.parseColor("#161616")
    private lateinit var root: LinearLayout

    /** True while we deliberately open another screen (picker, player, system dialog) and must stay unlocked. */
    private var keepOpen = false
    private var listView: LinearLayout? = null

    private var askedAllFiles = false
    private val allFilesLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { askMediaPermThenPick() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { launchPicker() }
    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { lockPicked(uris) } else { keepOpen = false }
    }
    /** One file being moved: where it came from, its MediaStore twin (if any) and its copy in the vault. */
    private data class Moved(val src: Uri, val media: Uri?, val vaultFile: File)

    private var awaiting: List<Moved> = emptyList()   // waiting for the system's delete confirmation (Android 11+)
    private val queue29 = ArrayDeque<Pair<Moved, RecoverableSecurityException>>()   // Android 10
    private var movedOk = 0
    private var notMoved = 0

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val items = awaiting
        awaiting = emptyList()
        if (r.resultCode == RESULT_OK) items.forEach { finishMove(it) } else items.forEach { rollback(it) }
        reportMove()
    }
    private val q29Launcher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val cur = queue29.removeFirstOrNull()
        if (cur != null) {
            if (r.resultCode == RESULT_OK) {
                runCatching { contentResolver.delete(cur.first.media!!, null, null) }
                finishMove(cur.first)
            } else rollback(cur.first)
        }
        if (!nextQ29()) reportMove()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hide vault from screenshots and the recent-apps preview
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }
        setContentView(root)
        showLock()
    }

    // The vault locks again whenever the user leaves it (home, app switch, opening a file).
    override fun onStart() {
        super.onStart()
        if (keepOpen) {
            keepOpen = false
            // the player closed itself because the user left the app: lock again
            if (PlayerActivity.leftApp) { PlayerActivity.leftApp = false; finish() }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !keepOpen) finish()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun rounded(fill: Int, r: Int, stroke: Int = Color.TRANSPARENT, sw: Int = 0) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = r.toFloat()
            if (sw > 0) setStroke(sw, stroke)
        }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(blue, dp(28))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(20) }
        setOnClickListener { onClick() }
    }

    private fun pinField(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(gray); setTextColor(Color.WHITE); textSize = 22f
        gravity = Gravity.CENTER
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(android.text.InputFilter.LengthFilter(8))
        background = rounded(Color.parseColor("#1C1C1C"), dp(16), Color.parseColor("#2A2A2A"), dp(1))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply { topMargin = dp(14) }
    }

    // ---------- lock screen ----------
    private fun showLock() {
        root.removeAllViews()
        val setup = !VaultStore.hasPin(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(80), dp(32), dp(32))
        }
        box.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_lock); setColorFilter(blue)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        })
        box.addView(label(if (setup) "Create vault PIN" else "Enter vault PIN", 22f, Color.WHITE, true)
            .apply { setPadding(0, dp(20), 0, dp(6)) })
        box.addView(label(
            if (setup) "Files you move here are hidden from Gallery and Files. Choose a 4–8 digit PIN."
            else "Your private files are locked.", 14f, gray).apply { gravity = Gravity.CENTER })

        val pin = pinField("PIN")
        val confirm = pinField("Confirm PIN")
        box.addView(pin)
        if (setup) box.addView(confirm)

        val err = label("", 13f, Color.parseColor("#FF5A5F")).apply { setPadding(0, dp(10), 0, 0) }
        box.addView(err)

        box.addView(button(if (setup) "Create vault" else "Unlock") {
            val p = pin.text.toString()
            if (setup) {
                when {
                    p.length < 4 -> err.text = "PIN must be at least 4 digits"
                    p != confirm.text.toString() -> err.text = "PINs don't match"
                    else -> { VaultStore.setPin(this, p); showFiles() }
                }
            } else {
                val wait = VaultStore.lockedForSeconds(this)
                if (wait > 0) { err.text = "Too many attempts. Try again in ${wait}s"; return@button }
                if (VaultStore.checkPin(this, p)) showFiles()
                else {
                    pin.setText("")
                    val w = VaultStore.lockedForSeconds(this)
                    err.text = if (w > 0) "Too many attempts. Try again in ${w}s" else "Wrong PIN"
                }
            }
        })
        if (!setup) {
            box.addView(label("Forgot PIN?", 14f, gray).apply {
                setPadding(0, dp(22), 0, dp(8))
                setOnClickListener {
                    AlertDialog.Builder(this@VaultActivity)
                        .setTitle("Erase vault?")
                        .setMessage("Without the PIN the vault can't be opened. Erasing deletes ALL files inside it permanently and lets you set a new PIN.")
                        .setPositiveButton("Erase everything") { _, _ -> VaultStore.eraseAll(this@VaultActivity); showLock() }
                        .setNegativeButton("Cancel", null).show()
                }
            })
        }
        root.addView(box)
    }

    // ---------- file list ----------
    private fun showFiles() {
        root.removeAllViews()
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        header.addView(label("Vault", 24f, Color.WHITE, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(label("Change PIN", 14f, blue, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { changePin() }
        })
        header.addView(label("Lock", 14f, blue, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { finish() }
        })
        root.addView(header)

        root.addView(LinearLayout(this).apply {
            setPadding(dp(20), 0, dp(20), dp(4))
            addView(button("🔒  Move videos & music into Vault") { pickFromPhone() }.apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(4)
            })
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listView = list
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        loadList(list)
    }

    private fun loadList(list: LinearLayout) {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                VaultStore.list(this@VaultActivity).map { it to thumb(it) }
            }
            list.removeAllViews()
            if (items.isEmpty()) {
                list.addView(label("Vault is empty.\nTap \"Move videos & music into Vault\" to hide videos that are already on your phone " +
                    "(in the picker open the Videos folder and select as many as you like). They are MOVED: after that they exist only inside the Vault. " +
                    "You can also tap ⋮ on a download in the Play tab and choose \"Move to Vault\".", 15f, gray).apply { setPadding(dp(20), dp(20), dp(20), dp(20)) })
            }
            items.forEach { (f, t) -> list.addView(row(f, t, list)) }
        }
    }

    private fun thumb(f: File): Bitmap? =
        if (VaultStore.mime(f).startsWith("video"))
            runCatching { ThumbnailUtils.createVideoThumbnail(f, Size(192, 192), null) }.getOrNull() else null

    private fun uriFor(f: File) = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun row(f: File, t: Bitmap?, list: LinearLayout): View {
        val mime = VaultStore.mime(f)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(10), dp(8), dp(10))
            setOnClickListener { open(f) }
        }
        row.addView(ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
            background = rounded(Color.parseColor("#262626"), dp(12))
            clipToOutline = true
            if (t != null) { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(t) }
            else {
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(18), dp(18), dp(18), dp(18))
                setImageResource(if (mime.startsWith("audio")) R.drawable.ic_music else R.drawable.ic_play)
                setColorFilter(blue)
            }
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(14); marginEnd = dp(8) }
        }
        col.addView(label(f.nameWithoutExtension, 15f, Color.WHITE, true).apply {
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(label(Formatter.formatShortFileSize(this, f.length()), 12f, gray).apply { setPadding(0, dp(6), 0, 0) })
        row.addView(col)
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_more); setColorFilter(gray)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { v ->
                PopupMenu(this@VaultActivity, v).apply {
                    menu.add("Open"); menu.add("Share"); menu.add("Move out of Vault"); menu.add("Delete")
                    setOnMenuItemClickListener { mi ->
                        when (mi.title.toString()) {
                            "Open" -> open(f)
                            "Share" -> share(f)
                            "Move out of Vault" -> lifecycleScope.launch {
                                val ok = withContext(Dispatchers.IO) { VaultStore.restore(this@VaultActivity, f) }
                                toast(if (ok) "Moved to Downloads/Savora" else "Couldn't move file")
                                loadList(list)
                            }
                            "Delete" -> AlertDialog.Builder(this@VaultActivity)
                                .setTitle("Delete permanently?").setMessage(f.name)
                                .setPositiveButton("Delete") { _, _ -> f.delete(); loadList(list) }
                                .setNegativeButton("Cancel", null).show()
                        }
                        true
                    }
                }.show()
            }
        })
        return row
    }

    private fun open(f: File) {
        val mime = VaultStore.mime(f)
        val group = when { mime.startsWith("video") -> "video"; mime.startsWith("audio") -> "audio"; else -> null }
        if (group == null) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(f), mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }.onFailure { toast("No app found to open this file") }
            return
        }
        val files = VaultStore.list(this).filter { VaultStore.mime(it).startsWith(group) }
        keepOpen = true
        startActivity(Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(files.map { Uri.fromFile(it).toString() }))
            .putStringArrayListExtra(PlayerActivity.EXTRA_NAMES, ArrayList(files.map { it.nameWithoutExtension }))
            .putExtra(PlayerActivity.EXTRA_INDEX, files.indexOf(f).coerceAtLeast(0))
            .putExtra(PlayerActivity.EXTRA_AUDIO, group == "audio")
            .putExtra(PlayerActivity.EXTRA_SECURE, true))
    }

    // ---------- lock videos that are already on the phone ----------
    private fun pickFromPhone() {
        keepOpen = true
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager() && !askedAllFiles) {
            askedAllFiles = true
            AlertDialog.Builder(this)
                .setTitle("Instant move")
                .setMessage("To MOVE files like a USB / file-manager transfer (instant, no copying, no extra space) Savora needs " +
                    "\"All files access\". On the next screen turn it ON for Savora, then come back.")
                .setPositiveButton("Allow") { _, _ -> openAllFilesSettings() }
                .setNegativeButton("Not now") { _, _ -> askMediaPermThenPick() }
                .setOnCancelListener { keepOpen = false }
                .show()
            return
        }
        askMediaPermThenPick()
    }

    private fun openAllFilesSettings() {
        keepOpen = true
        val pkg = Uri.parse("package:$packageName")
        runCatching { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)) }
            .onFailure { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
    }

    private fun askMediaPermThenPick() {
        keepOpen = true
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) { launchPicker(); return }
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) launchPicker() else permLauncher.launch(missing.toTypedArray())
    }

    private fun launchPicker() {
        keepOpen = true
        pickLauncher.launch(arrayOf("video/*", "audio/*"))
    }

    private fun lockPicked(uris: List<Uri>) {
        keepOpen = true
        movedOk = 0; notMoved = 0
        val dlg = AlertDialog.Builder(this).setTitle("Moving to Vault")
            .setMessage("Starting…").setCancelable(false).show()
        lifecycleScope.launch {
            val moved = mutableListOf<Moved>()
            uris.forEachIndexed { i, u ->
                dlg.setMessage("Moving ${i + 1} of ${uris.size}…\nPlease keep the app open.")
                // 1) real MOVE (rename, instant, nothing is copied) when "All files access" is on
                val fastDone = withContext(Dispatchers.IO) {
                    val src = if (VaultStore.canFastMove()) pathFor(u) else null
                    src != null && VaultStore.fastMove(this@VaultActivity, src) != null
                }
                if (fastDone) {
                    movedOk++
                } else {
                    // 2) fallback: copy, verify, then delete the original (system asks for confirmation)
                    val f = withContext(Dispatchers.IO) { VaultStore.importFromUri(this@VaultActivity, u) }
                    if (f != null) moved.add(Moved(u, toMediaStoreUri(u), f)) else notMoved++
                }
            }
            dlg.dismiss()
            listView?.let { loadList(it) }
            val waiting = moved.isNotEmpty() && removeOriginals(moved)
            if (!waiting) reportMove()
        }
    }

    /** The copy is in the vault. If the original cannot be removed, the copy is deleted again: it is a MOVE or nothing. */
    private fun rollback(m: Moved) { m.vaultFile.delete(); notMoved++ }

    private fun originalGone(m: Moved): Boolean {
        val mu = m.media ?: return true
        return runCatching { contentResolver.query(mu, arrayOf("_id"), null, null, null)?.use { it.count == 0 } ?: true }
            .getOrDefault(false)
    }

    private fun finishMove(m: Moved) { if (originalGone(m)) movedOk++ else rollback(m) }

    /** Deletes the originals. Returns true while a system confirmation is on screen. */
    private fun removeOriginals(items: List<Moved>): Boolean {
        val media = mutableListOf<Moved>()
        items.forEach { m ->
            if (m.media != null) media.add(m)
            else if (runCatching { DocumentsContract.deleteDocument(contentResolver, m.src) }.getOrDefault(false)) movedOk++
            else rollback(m)
        }
        if (media.isEmpty()) return false

        if (Build.VERSION.SDK_INT >= 30) {
            val req = runCatching { MediaStore.createDeleteRequest(contentResolver, media.map { it.media!! }) }.getOrNull()
            if (req == null) { media.forEach { rollback(it) }; return false }
            awaiting = media
            keepOpen = true
            deleteLauncher.launch(IntentSenderRequest.Builder(req.intentSender).build())
            return true
        }
        // Android 10: delete one by one, the system asks for each file it does not let us delete silently
        media.forEach { m ->
            try {
                if (contentResolver.delete(m.media!!, null, null) > 0) finishMove(m) else rollback(m)
            } catch (e: RecoverableSecurityException) {
                queue29.add(m to e)
            } catch (e: Throwable) {
                rollback(m)
            }
        }
        return nextQ29()
    }

    private fun nextQ29(): Boolean {
        val first = queue29.firstOrNull() ?: return false
        keepOpen = true
        q29Launcher.launch(IntentSenderRequest.Builder(first.second.userAction.actionIntent.intentSender).build())
        return true
    }

    private fun reportMove() {
        keepOpen = false
        listView?.let { loadList(it) }
        val msg = StringBuilder()
        if (movedOk > 0) msg.append("$movedOk file(s) moved to Vault. They are not anywhere else on the phone now.")
        if (notMoved > 0) {
            if (msg.isNotEmpty()) msg.append("\n")
            msg.append("$notMoved file(s) were NOT moved (the original could not be removed, or storage is full). They are still where they were.")
        }
        if (msg.isEmpty()) msg.append("Nothing was moved.")
        Toast.makeText(this, msg.toString(), Toast.LENGTH_LONG).show()
        movedOk = 0; notMoved = 0
    }

    /** Real path of a picked file (needed for an instant move). */
    private fun pathFor(u: Uri): File? {
        if (u.authority == "com.android.externalstorage.documents") {
            val id = runCatching { DocumentsContract.getDocumentId(u) }.getOrNull() ?: return null
            val parts = id.split(":", limit = 2)
            if (parts.size == 2 && parts[0] == "primary")
                return File(Environment.getExternalStorageDirectory(), parts[1]).takeIf { it.isFile }
            return null
        }
        val mu = toMediaStoreUri(u) ?: return null
        val path = runCatching {
            contentResolver.query(mu, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull() ?: return null
        return File(path).takeIf { it.isFile }
    }

    private fun toMediaStoreUri(u: Uri): Uri? {
        if (u.authority == "media") return u
        if (u.authority != "com.android.providers.media.documents") return null
        val id = runCatching { DocumentsContract.getDocumentId(u) }.getOrNull() ?: return null
        val parts = id.split(":")
        if (parts.size != 2) return null
        val n = parts[1].toLongOrNull() ?: return null
        val base = when (parts[0]) {
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> return null
        }
        return ContentUris.withAppendedId(base, n)
    }

    private fun share(f: File) {
        runCatching {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType(VaultStore.mime(f))
                    .putExtra(Intent.EXTRA_STREAM, uriFor(f))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
        }
    }

    private fun changePin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val cur = pinField("Current PIN"); val n1 = pinField("New PIN"); val n2 = pinField("Confirm new PIN")
        listOf(cur, n1, n2).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Change PIN").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val a = n1.text.toString()
                when {
                    !VaultStore.checkPin(this, cur.text.toString()) -> toast("Current PIN is wrong")
                    a.length < 4 -> toast("PIN must be at least 4 digits")
                    a != n2.text.toString() -> toast("PINs don't match")
                    else -> { VaultStore.setPin(this, a); toast("PIN changed") }
                }
            }.setNegativeButton("Cancel", null).show()
    }
}
