package com.savora.downloader

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Built-in video / audio player: queue, next / previous, speed, seek, remembers where you stopped. */
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_NAMES = "names"
        const val EXTRA_INDEX = "index"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_SECURE = "secure"

        /** Set when a vault video was closed because the user left the app, so the vault locks itself again. */
        @Volatile var leftApp = false
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var backView: TextView
    private lateinit var audioName: TextView
    private var uris: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var index = 0
    private var resumePos: Long = C.TIME_UNSET
    private var secure = false
    private var audio = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uris = intent.getStringArrayListExtra(EXTRA_URIS) ?: emptyList()
        names = intent.getStringArrayListExtra(EXTRA_NAMES) ?: emptyList()
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, (uris.size - 1).coerceAtLeast(0))
        audio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        secure = intent.getBooleanExtra(EXTRA_SECURE, false)
        if (uris.isEmpty()) { finish(); return }

        if (secure) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        playerView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            useController = true
            controllerShowTimeoutMs = if (audio) 0 else 3500
            controllerHideOnTouch = !audio
        }
        root.addView(playerView)

        if (audio) {
            val art = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(32), 0, dp(32), dp(80))
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }
            art.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_music)
                setColorFilter(Color.parseColor("#2D7BFF"))
                layoutParams = LinearLayout.LayoutParams(dp(110), dp(110))
            })
            audioName = TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; maxLines = 3; ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(24), 0, 0)
            }
            art.addView(audioName)
            root.addView(art)
        } else {
            audioName = TextView(this)
        }

        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(60), dp(18), dp(16), dp(14))
            setBackgroundColor(Color.parseColor("#66000000"))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        }
        backView = TextView(this).apply {
            text = "←"; setTextColor(Color.WHITE); textSize = 26f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            setOnClickListener { finish() }
        }
        root.addView(titleView)
        root.addView(backView)

        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            titleView.visibility = v
            backView.visibility = v
        })

        setContentView(root)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onStart() {
        super.onStart()
        if (player == null) buildPlayer()
    }

    override fun onStop() {
        super.onStop()
        savePos()
        player?.release()
        player = null
        playerView.player = null
        // A vault video must never stay open behind the user's back.
        if (secure && !isFinishing && !isChangingConfigurations) {
            leftApp = true
            finish()
        }
    }

    private fun buildPlayer() {
        val p = ExoPlayer.Builder(this).build()
        val items = uris.mapIndexed { i, u ->
            MediaItem.Builder()
                .setUri(Uri.parse(u))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(names.getOrNull(i) ?: "").build())
                .build()
        }
        var start = resumePos
        if (start == C.TIME_UNSET && !secure) {
            val saved = getSharedPreferences("player", MODE_PRIVATE).getLong(uris[index], 0L)
            if (saved > 5000) start = saved
        }
        p.setMediaItems(items, index, start)
        p.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateTitle() }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Can't play this file (${error.errorCodeName})", Toast.LENGTH_LONG).show()
            }
        })
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
        updateTitle()
        playerView.showController()
    }

    private fun updateTitle() {
        val i = player?.currentMediaItemIndex ?: index
        val t = names.getOrNull(i) ?: ""
        titleView.text = t
        audioName.text = t
    }

    private fun savePos() {
        val p = player ?: return
        index = p.currentMediaItemIndex
        resumePos = p.currentPosition
        if (secure) return
        val key = uris.getOrNull(index) ?: return
        val dur = p.duration
        val e = getSharedPreferences("player", MODE_PRIVATE).edit()
        if (dur != C.TIME_UNSET && dur > 0 && p.currentPosition > dur - 5000) e.remove(key)
        else e.putLong(key, p.currentPosition)
        e.apply()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
