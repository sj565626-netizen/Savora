package com.savora.downloader

import java.util.concurrent.ConcurrentHashMap

/** In-memory list of running / failed downloads so the Play tab can show them live. */
object DownloadTracker {
    data class Task(
        val id: Int,
        val name: String,
        val status: String,
        val pct: Int,          // -1 = indeterminate
        val failed: Boolean = false,
        val url: String = "",
        val paused: Boolean = false
    )

    private val tasks = ConcurrentHashMap<Int, Task>()
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var onFinished: (() -> Unit)? = null

    fun snapshot(): List<Task> = tasks.values.sortedByDescending { it.id }

    /** Called with every progress update. Texts ending in "…" are status messages, not file names. */
    fun update(id: Int, title: String, pct: Int, url: String) {
        val prev = tasks[id]
        val isStatus = title.endsWith("…")
        val name = if (isStatus) (prev?.name?.takeIf { it.isNotEmpty() } ?: "") else title
        val status = when {
            isStatus -> title
            pct >= 0 -> "Downloading… $pct%"
            else -> "Starting…"
        }
        tasks[id] = Task(id, name, status, if (pct >= 0) pct else (prev?.pct ?: -1), false, url)
        onChange?.invoke()
    }

    fun get(id: Int): Task? = tasks[id]

    fun setPaused(id: Int, paused: Boolean) {
        val t = tasks[id] ?: return
        tasks[id] = t.copy(paused = paused, status = if (paused) "Paused" else t.status)
        onChange?.invoke()
    }

    fun fail(id: Int, message: String) {
        val prev = tasks[id]
        tasks[id] = Task(id, prev?.name ?: "", message, 0, true, prev?.url ?: "")
        onChange?.invoke()
    }

    fun remove(id: Int, finished: Boolean) {
        tasks.remove(id)
        onChange?.invoke()
        if (finished) onFinished?.invoke()
    }
}
