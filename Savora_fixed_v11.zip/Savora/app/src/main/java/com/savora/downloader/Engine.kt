package com.savora.downloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    @Volatile var ready = false

    @Volatile var lastError: String = ""

    /** Picks the "nightly" (or any) update channel whether the library models it as enum, sealed class or static field. */
    private fun pickChannel(t: Class<*>, prefer: String): Any? {
        if (t.isEnum) {
            val c = t.enumConstants!!
            return c.firstOrNull { (it as Enum<*>).name.contains(prefer, true) } ?: c.first()
        }
        val statics = t.fields.filter { java.lang.reflect.Modifier.isStatic(it.modifiers) && t.isAssignableFrom(it.type) }
        statics.firstOrNull { it.name.contains(prefer, true) }?.let { return it.get(null) }
        for (c in t.declaredClasses) {
            if (c.simpleName.contains(prefer, true)) {
                runCatching { return c.getField("INSTANCE").get(null) }
            }
        }
        statics.firstOrNull()?.let { return it.get(null) }
        for (c in t.declaredClasses) runCatching { return c.getField("INSTANCE").get(null) }
        return null
    }

    private fun tryUpdate(ctx: Context, prefer: String) {
        val ytdl = YoutubeDL.getInstance()
        val methods = Class.forName("com.yausername.youtubedl_android.YoutubeDL").methods
            .filter { it.name == "updateYoutubeDL" }.sortedByDescending { it.parameterCount }
        if (methods.isEmpty()) throw IllegalStateException("update not supported")
        var last: Throwable? = null
        for (m in methods) {
            try {
                val args = m.parameterTypes.map { t ->
                    if (Context::class.java.isAssignableFrom(t)) ctx.applicationContext else pickChannel(t, prefer)
                }
                m.invoke(ytdl, *args.toTypedArray())
                return
            } catch (e: java.lang.reflect.InvocationTargetException) {
                last = e.targetException ?: e
            } catch (e: Throwable) {
                last = e
            }
        }
        throw last ?: IllegalStateException("update failed")
    }

    @Synchronized
    fun update(ctx: Context) {
        val prefs = ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE)
        prefs.edit().putLong("last_try", System.currentTimeMillis()).apply()
        try {
            try { tryUpdate(ctx, "NIGHTLY") } catch (e: Throwable) { tryUpdate(ctx, "STABLE") }
        } catch (e: Throwable) {
            lastError = e.message ?: e.javaClass.simpleName
            throw e
        }
        lastError = ""
        ready = true
        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }

    fun isYoutube(url: String) =
        Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE).containsMatchIn(url)

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"

    /** Number of strategies to try for this link (sites change constantly, so we try several). */
    fun variants(url: String) = 5

    private fun origin(url: String) = Regex("^(https?://[^/]+)").find(url)?.value ?: url

    /**
     * YouTube  0: QuickJS + EJS | 1: android_vr | 2: tv_simply/web_safari | 3: plain | 4: android_vr + progressive file
     * Others   0: plain | 1: mobile identity + referer | 2: lenient TLS + ffmpeg for HLS | 3: ffmpeg downloader + progressive file
     */
    fun tune(req: com.yausername.youtubedl_android.YoutubeDLRequest, url: String, variant: Int) {
        if (isYoutube(url)) {
            when (variant) {
                0 -> { req.addOption("--js-runtimes", "quickjs"); req.addOption("--remote-components", "ejs:github") }
                1, 4 -> req.addOption("--extractor-args", "youtube:player_client=android_vr")
                2 -> { req.addOption("--js-runtimes", "quickjs"); req.addOption("--extractor-args", "youtube:player_client=tv_simply,web_safari") }
                else -> {}
            }
        } else {
            when (variant) {
                1 -> { req.addOption("--user-agent", MOBILE_UA); req.addOption("--referer", origin(url) + "/"); req.addOption("--geo-bypass") }
                2 -> { req.addOption("--geo-bypass"); req.addOption("--legacy-server-connect"); req.addOption("--no-check-certificates"); req.addOption("--downloader", "m3u8:ffmpeg") }
                3 -> { req.addOption("--user-agent", MOBILE_UA); req.addOption("--referer", origin(url) + "/"); req.addOption("--downloader", "ffmpeg") }
                4 -> { req.addOption("--user-agent", DESKTOP_UA); req.addOption("--referer", origin(url) + "/"); req.addOption("--geo-bypass"); req.addOption("--no-check-certificates"); req.addOption("--legacy-server-connect") }
                else -> {}
            }
        }
    }

    /** Daily background refresh so the engine stays current without the user doing anything. */
    fun refreshInBackground(ctx: Context) {
        val prefs = ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("last_update", 0) < 12 * 3600_000L || now - prefs.getLong("last_try", 0) < 10 * 60_000L) return
        Thread { runCatching { update(ctx) } }.start()
    }

    fun ensure(ctx: Context) {
        if (ready) return
        val prefs = ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("last_update", 0) < 12 * 3600_000L || now - prefs.getLong("last_try", 0) < 10 * 60_000L) { ready = true; return }
        runCatching { update(ctx) }
        ready = true   // even if the update failed, continue with the bundled engine
    }
}
