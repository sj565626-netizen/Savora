package com.savora.downloader

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var btn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var rbAudio: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        urlInput = findViewById(R.id.urlInput)
        btn = findViewById(R.id.btnDownload)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        rbAudio = findViewById(R.id.rbAudio)
        btn.setOnClickListener { start() }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            urlInput.setText(Regex("https?://\\S+").find(t)?.value ?: t)
        }
    }

    private fun start() {
        val url = urlInput.text.toString().trim()
        if (url.isEmpty()) {
            Toast.makeText(this, getString(R.string.paste_link), Toast.LENGTH_SHORT).show()
            return
        }
        val audio = rbAudio.isChecked
        btn.isEnabled = false
        progress.progress = 0
        status.text = getString(R.string.preparing)
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { download(url, audio) } }
            btn.isEnabled = true
            result.onSuccess { n ->
                progress.progress = 100
                status.text = if (n > 0) getString(R.string.saved) else getString(R.string.nothing)
            }.onFailure { e ->
                status.text = getString(R.string.failed, e.message?.take(200) ?: "")
            }
        }
    }

    private fun download(url: String, audio: Boolean): Int {
        val dir = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
        val req = YoutubeDLRequest(url)
        req.addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
        req.addOption("--no-playlist")
        if (audio) {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
        } else {
            req.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b")
            req.addOption("--merge-output-format", "mp4")
        }
        YoutubeDL.getInstance().execute(req, "savora") { p, _, _ ->
            runOnUiThread {
                val v = p.toInt().coerceIn(0, 100)
                progress.progress = v
                status.text = getString(R.string.downloading, v)
            }
        }
        val files = dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") } ?: emptyList()
        files.forEach { saveToDownloads(it) }
        dir.deleteRecursively()
        return files.size
    }

    private fun saveToDownloads(f: File) {
        val mime = when (f.extension.lowercase()) {
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            else -> "application/octet-stream"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Savora")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
    }
}
