package com.savora.downloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    @Volatile var ready = false

    @Synchronized
    fun update(ctx: Context) {
        val ytdl = YoutubeDL.getInstance()
        val m = Class.forName("com.yausername.youtubedl_android.YoutubeDL").methods
            .filter { it.name == "updateYoutubeDL" }.maxByOrNull { it.parameterCount }
            ?: throw IllegalStateException("update not supported")
        val args = m.parameterTypes.map { t ->
            when {
                Context::class.java.isAssignableFrom(t) -> ctx.applicationContext
                t.isEnum -> t.enumConstants!!.firstOrNull { (it as Enum<*>).name.contains("NIGHTLY", true) }
                    ?: t.enumConstants!!.first()
                else -> null
            }
        }
        try {
            m.invoke(ytdl, *args.toTypedArray())
        } catch (e: java.lang.reflect.InvocationTargetException) {
            throw e.targetException ?: e
        }
        ready = true
        ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE)
            .edit().putLong("last_update", System.currentTimeMillis()).apply()
    }

    fun isYoutube(url: String) =
        Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE).containsMatchIn(url)

    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"

    /** Number of strategies to try for this link (sites change constantly, so we try several). */
    fun variants(url: String) = if (isYoutube(url)) 4 else 3

    /**
     * YouTube  0: QuickJS + EJS solver | 1: android_vr client | 2: tv_simply/web_safari | 3: plain
     * Others   0: plain | 1: mobile browser identity + geo-bypass | 2: lenient TLS + geo-bypass
     */
    fun tune(req: com.yausername.youtubedl_android.YoutubeDLRequest, url: String, variant: Int) {
        if (isYoutube(url)) {
            when (variant) {
                0 -> { req.addOption("--js-runtimes", "quickjs"); req.addOption("--remote-components", "ejs:github") }
                1 -> req.addOption("--extractor-args", "youtube:player_client=android_vr")
                2 -> { req.addOption("--js-runtimes", "quickjs"); req.addOption("--extractor-args", "youtube:player_client=tv_simply,web_safari") }
                else -> {}
            }
        } else {
            when (variant) {
                1 -> { req.addOption("--user-agent", MOBILE_UA); req.addOption("--geo-bypass") }
                2 -> { req.addOption("--geo-bypass"); req.addOption("--legacy-server-connect"); req.addOption("--no-check-certificates") }
                else -> {}
            }
        }
    }

    /** Daily background refresh so the engine stays current without the user doing anything. */
    fun refreshInBackground(ctx: Context) {
        val prefs = ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE)
        if (System.currentTimeMillis() - prefs.getLong("last_update", 0) < 12 * 3600_000L) return
        Thread { runCatching { update(ctx) } }.start()
    }

    fun ensure(ctx: Context) {
        if (ready) return
        val last = ctx.applicationContext.getSharedPreferences("engine", Context.MODE_PRIVATE).getLong("last_update", 0)
        if (System.currentTimeMillis() - last < 12 * 3600_000L) { ready = true; return }
        ready = runCatching { update(ctx) }.isSuccess
    }
}
