package com.savora.downloader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ThumbnailUtils
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.text.format.Formatter
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class VaultActivity : AppCompatActivity() {

    private val blue = Color.parseColor("#2D7BFF")
    private val gray = Color.parseColor("#8A8A8A")
    private val bg = Color.parseColor("#161616")
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hide vault from screenshots and the recent-apps preview
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }
        setContentView(root)
        showLock()
    }

    // The vault locks again whenever the user leaves it (home, app switch, opening a file).
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) finish()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun rounded(fill: Int, r: Int, stroke: Int = Color.TRANSPARENT, sw: Int = 0) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = r.toFloat()
            if (sw > 0) setStroke(sw, stroke)
        }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(blue, dp(28))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(20) }
        setOnClickListener { onClick() }
    }

    private fun pinField(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(gray); setTextColor(Color.WHITE); textSize = 22f
        gravity = Gravity.CENTER
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(android.text.InputFilter.LengthFilter(8))
        background = rounded(Color.parseColor("#1C1C1C"), dp(16), Color.parseColor("#2A2A2A"), dp(1))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply { topMargin = dp(14) }
    }

    // ---------- lock screen ----------
    private fun showLock() {
        root.removeAllViews()
        val setup = !VaultStore.hasPin(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(80), dp(32), dp(32))
        }
        box.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_lock); setColorFilter(blue)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        })
        box.addView(label(if (setup) "Create vault PIN" else "Enter vault PIN", 22f, Color.WHITE, true)
            .apply { setPadding(0, dp(20), 0, dp(6)) })
        box.addView(label(
            if (setup) "Files you move here are hidden from Gallery and Files. Choose a 4–8 digit PIN."
            else "Your private files are locked.", 14f, gray).apply { gravity = Gravity.CENTER })

        val pin = pinField("PIN")
        val confirm = pinField("Confirm PIN")
        box.addView(pin)
        if (setup) box.addView(confirm)

        val err = label("", 13f, Color.parseColor("#FF5A5F")).apply { setPadding(0, dp(10), 0, 0) }
        box.addView(err)

        box.addView(button(if (setup) "Create vault" else "Unlock") {
            val p = pin.text.toString()
            if (setup) {
                when {
                    p.length < 4 -> err.text = "PIN must be at least 4 digits"
                    p != confirm.text.toString() -> err.text = "PINs don't match"
                    else -> { VaultStore.setPin(this, p); showFiles() }
                }
            } else {
                val wait = VaultStore.lockedForSeconds(this)
                if (wait > 0) { err.text = "Too many attempts. Try again in ${wait}s"; return@button }
                if (VaultStore.checkPin(this, p)) showFiles()
                else {
                    pin.setText("")
                    val w = VaultStore.lockedForSeconds(this)
                    err.text = if (w > 0) "Too many attempts. Try again in ${w}s" else "Wrong PIN"
                }
            }
        })
        if (!setup) {
            box.addView(label("Forgot PIN?", 14f, gray).apply {
                setPadding(0, dp(22), 0, dp(8))
                setOnClickListener {
                    AlertDialog.Builder(this@VaultActivity)
                        .setTitle("Erase vault?")
                        .setMessage("Without the PIN the vault can't be opened. Erasing deletes ALL files inside it permanently and lets you set a new PIN.")
                        .setPositiveButton("Erase everything") { _, _ -> VaultStore.eraseAll(this@VaultActivity); showLock() }
                        .setNegativeButton("Cancel", null).show()
                }
            })
        }
        root.addView(box)
    }

    // ---------- file list ----------
    private fun showFiles() {
        root.removeAllViews()
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        header.addView(label("Vault", 24f, Color.WHITE, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(label("Change PIN", 14f, blue, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { changePin() }
        })
        header.addView(label("Lock", 14f, blue, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { finish() }
        })
        root.addView(header)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        loadList(list)
    }

    private fun loadList(list: LinearLayout) {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                VaultStore.list(this@VaultActivity).map { it to thumb(it) }
            }
            list.removeAllViews()
            if (items.isEmpty()) {
                list.addView(label("Vault is empty.\nIn the Play tab, tap ⋮ on a download and choose \"Move to Vault\", " +
                    "or tick \"Save to Vault\" before downloading.", 15f, gray).apply { setPadding(dp(20), dp(20), dp(20), dp(20)) })
            }
            items.forEach { (f, t) -> list.addView(row(f, t, list)) }
        }
    }

    private fun thumb(f: File): Bitmap? =
        if (VaultStore.mime(f).startsWith("video"))
            runCatching { ThumbnailUtils.createVideoThumbnail(f, Size(192, 192), null) }.getOrNull() else null

    private fun uriFor(f: File) = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun row(f: File, t: Bitmap?, list: LinearLayout): View {
        val mime = VaultStore.mime(f)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(10), dp(8), dp(10))
            setOnClickListener { open(f) }
        }
        row.addView(ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
            background = rounded(Color.parseColor("#262626"), dp(12))
            clipToOutline = true
            if (t != null) { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(t) }
            else {
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(18), dp(18), dp(18), dp(18))
                setImageResource(if (mime.startsWith("audio")) R.drawable.ic_music else R.drawable.ic_play)
                setColorFilter(blue)
            }
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(14); marginEnd = dp(8) }
        }
        col.addView(label(f.nameWithoutExtension, 15f, Color.WHITE, true).apply {
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(label(Formatter.formatShortFileSize(this, f.length()), 12f, gray).apply { setPadding(0, dp(6), 0, 0) })
        row.addView(col)
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_more); setColorFilter(gray)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { v ->
                PopupMenu(this@VaultActivity, v).apply {
                    menu.add("Open"); menu.add("Share"); menu.add("Move out of Vault"); menu.add("Delete")
                    setOnMenuItemClickListener { mi ->
                        when (mi.title.toString()) {
                            "Open" -> open(f)
                            "Share" -> share(f)
                            "Move out of Vault" -> lifecycleScope.launch {
                                val ok = withContext(Dispatchers.IO) { VaultStore.restore(this@VaultActivity, f) }
                                toast(if (ok) "Moved to Downloads/Savora" else "Couldn't move file")
                                loadList(list)
                            }
                            "Delete" -> AlertDialog.Builder(this@VaultActivity)
                                .setTitle("Delete permanently?").setMessage(f.name)
                                .setPositiveButton("Delete") { _, _ -> f.delete(); loadList(list) }
                                .setNegativeButton("Cancel", null).show()
                        }
                        true
                    }
                }.show()
            }
        })
        return row
    }

    private fun open(f: File) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(f), VaultStore.mime(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }.onFailure { toast("No app found to open this file") }
    }

    private fun share(f: File) {
        runCatching {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType(VaultStore.mime(f))
                    .putExtra(Intent.EXTRA_STREAM, uriFor(f))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
        }
    }

    private fun changePin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val cur = pinField("Current PIN"); val n1 = pinField("New PIN"); val n2 = pinField("Confirm new PIN")
        listOf(cur, n1, n2).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Change PIN").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val a = n1.text.toString()
                when {
                    !VaultStore.checkPin(this, cur.text.toString()) -> toast("Current PIN is wrong")
                    a.length < 4 -> toast("PIN must be at least 4 digits")
                    a != n2.text.toString() -> toast("PINs don't match")
                    else -> { VaultStore.setPin(this, a); toast("PIN changed") }
                }
            }.setNegativeButton("Cancel", null).show()
    }
}
